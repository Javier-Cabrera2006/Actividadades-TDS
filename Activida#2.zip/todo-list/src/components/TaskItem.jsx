import { useDispatch } from "react-redux";
import { deleteTask } from "../features/tasks/tasksSlice";

function TaskItem({ task }) {
  const dispatch = useDispatch();

  return (
    <div className="task-item">
      <div>
        <h3>{task.title}</h3>
        <p>Fecha límite: {task.date}</p>
      </div>

      <button onClick={() => dispatch(deleteTask(task.id))}>
        Eliminar
      </button>
    </div>
  );
}

export default TaskItem;
